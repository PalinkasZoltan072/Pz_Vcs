import { createFileRoute, useNavigate } from '@tanstack/react-router'
import { Button } from "@/components/ui/button"
import { useState } from "react"

export const Route = createFileRoute('/pets/')({
  component: RouteComponent,
})

const random = (a: number, b: number) => {
  return Math.floor(Math.random() * (b - a + 1) + a);
}

const kodgeneralas = () => {
  return random(100, 999) + String.fromCharCode(random(97, 122)) + String.fromCharCode(random(97, 122));
}

const adatok = [
  { id: kodgeneralas(), nev: "Nagy János", szido: "1978.03.12", fiz: random(100, 500) * 1000 },
  { id: kodgeneralas(), nev: "Kis Pista", szido: "1990.05.22", fiz: random(100, 500) * 1000 },
  { id: kodgeneralas(), nev: "Cinc Éva", szido: "1991.05.11", fiz: random(100, 500) * 1000 },
  { id: kodgeneralas(), nev: "Est Hajnalka", szido: "1980.10.12", fiz: random(100, 500) * 1000 },
];

function RouteComponent() {
  const navigate = useNavigate();
  const [lista, setLista] = useState([...adatok]);

  const [aktModositId, setAktModositId] = useState<string | null>(null);
  const [ujNev, setUjNev] = useState("");
  const [ujSzido, setUjSzido] = useState("");
  const [ujFiz, setUjFiz] = useState("");

  const [ujNevAdd, setUjNevAdd] = useState("");
  const [ujSzidoAdd, setUjSzidoAdd] = useState("");
  const [ujFizAdd, setUjFizAdd] = useState("");

  const torles = (id: string) => setLista(lista.filter(x => x.id !== id));
  const modositGomb = (elem: any) => { setAktModositId(elem.id); setUjNev(elem.nev); setUjSzido(elem.szido); setUjFiz(elem.fiz); };
  const mentes = (id: string) => { 
    setLista(lista.map(elem => elem.id === id ? { ...elem, nev: ujNev, szido: ujSzido, fiz: Number(ujFiz) } : elem)); 
    setAktModositId(null);
  };
  const hozzaadas = () => {
    const ujElem = { id: kodgeneralas(), nev: ujNevAdd, szido: ujSzidoAdd, fiz: Number(ujFizAdd) };
    setLista([...lista, ujElem]);
    setUjNevAdd(""); setUjSzidoAdd(""); setUjFizAdd("");
  };

  return (
    <div className="p-6">
      {/* Új elem hozzáadása */}
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <input placeholder="Név" value={ujNevAdd} onChange={(e) => setUjNevAdd(e.target.value)} className="border p-2 rounded flex-1" />
        <input placeholder="Születési idő" value={ujSzidoAdd} onChange={(e) => setUjSzidoAdd(e.target.value)} className="border p-2 rounded flex-1" />
        <input placeholder="Cafeteria (Ft)" value={ujFizAdd} onChange={(e) => setUjFizAdd(e.target.value)} className="border p-2 rounded flex-1" />
        <Button onClick={hozzaadas} className="bg-blue-500 text-white px-4 py-2 rounded">Hozzáadás</Button>
      </div>

      {/* Lista kártyás elrendezésben */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {lista.map(elem => (
          <div key={elem.id} className="border rounded shadow p-4 flex flex-col gap-2">
            <p><b>Azonosító:</b> {elem.id}</p>

            {aktModositId === elem.id ? (
              <>
                <input value={ujNev} onChange={(e) => setUjNev(e.target.value)} className="border p-1 rounded" />
                <input value={ujSzido} onChange={(e) => setUjSzido(e.target.value)} className="border p-1 rounded" />
                <input value={ujFiz} onChange={(e) => setUjFiz(e.target.value)} className="border p-1 rounded" />
              </>
            ) : (
              <>
                <p><b>Név:</b> {elem.nev}</p>
                <p><b>Születési idő:</b> {elem.szido}</p>
                <p><b>Cafeteria:</b> {elem.fiz} Ft</p>
              </>
            )}

            <div className="flex gap-2 mt-2">
              {aktModositId === elem.id ? (
                <Button onClick={() => mentes(elem.id)} className="bg-green-500 text-white px-2 py-1 rounded flex-1">Mentés</Button>
              ) : (
                <Button onClick={() => modositGomb(elem)} className="bg-yellow-400 text-white px-2 py-1 rounded flex-1">Módosítás</Button>
              )}
              <Button onClick={() => torles(elem.id)} className="bg-red-500 text-white px-2 py-1 rounded flex-1">Törlés</Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}